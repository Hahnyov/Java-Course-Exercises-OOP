package Exercises.WorkingWIthAbstractions.P03TrafficLight;

public enum Lights {
    RED,
    GREEN,
    YELLOW;

}
